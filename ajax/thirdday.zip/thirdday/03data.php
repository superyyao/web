<?php 
$script = 'alert(123);';
echo $script;
 ?>
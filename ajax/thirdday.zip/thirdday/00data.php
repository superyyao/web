<?php 
echo 1;
 ?>
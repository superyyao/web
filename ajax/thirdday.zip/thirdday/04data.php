<?php 

$text = 'hello world';

echo $text;



 ?>
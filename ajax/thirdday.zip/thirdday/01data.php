<?php 

$arr = array("username"=>"zhangsan","password"=>"456");

echo json_encode($arr);


 ?>